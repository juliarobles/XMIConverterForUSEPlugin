package main.model.umltouse;

class U9_CountUnnamed {
	
	private int countUnnamed;
	
	public U9_CountUnnamed() {
		this.countUnnamed = 0;
	}
	
	public void countUnnamedAddOne() {
		countUnnamed++;
	}
	
	public int getCountUnnamed() {
		return countUnnamed;
	}
	
}
